from tkinter import *
from tkinter import font
from tkinter import ttk
from tkinter import messagebox
import urllib.request
import xml.etree.ElementTree as etree
import webbrowser
#from Internet import *


menu ={'0':'시간별 국제선','1':'시간별 국내선','2':'공항별 국내선','3':'종합 날씨 조회','4':'면세점 시설 검색','5':'비면세점 시설 검색','6':'공항 지도 사이트 연결'}
dic = {'0': '[신라면세점]', '1': '[롯데면세점]', '2': '[SM면세점]', '3': '[신세계면세점]', '4': '[엔타스면세점]', '5': '[시티면세점]',
           '6': '[삼익면세점]'}
loopFlag = 1
key = 'QydOrzDVYNDcxRwTCTjElQ8FWVC7fQgJ8JVlglIlMmFtva3gU65%2BRmV%2FlyxorjQzmRAiXGxM%2F2E1PXAC56NWdg%3D%3D'

startTime =0.0
endTime =0.0
global sentry
global eentry
global duty

window = Tk()

def printMenu():
    print("**********************************************")
    print("             실시간 항공운항 서비스              ")
    print("**********************************************")
    print("             Menu                             ")
    print("             시간대별 국제 항공편 검색 :s         ")
    print("             시간대별 국내 항공편 검색 :d         ")
    print("             공항별   국내선 검색  :h            ")
    print("             종합 날씨 조회 :     r             ")
    print("             METAR 조회:          w            ")
    print("             면세점 시설 검색:      f           ")
    print("             비면세점 구역 매장 검색:n            ")
    print("             프로그램 종료:       q             ")
    print("**********************************************")


def QuitBookMgr():
    global loopFlag
    loopFlag=0



def TopText():
    MainText = Label(window , text="[항공정보 APP]", font = 'helvetica 23')
    MainText.pack()
    MainText.place(x=240)

def SearchButtonAction():
    global menu
    global combo
    global RenderText

    InitRenderText()
    #RenderText.configure(state='normal')
    #RenderText.delete(0.0,END)
    s=combo.get()
    if s==menu['0']:
        #시간별 국내선
        Inter_airline()
    elif s == menu['1']:
        #시간별 국제선
        dom_airline()
    elif s ==menu['2']:
        #공항별 국제선
        airportDomainSearch()
    elif s == menu['3']:
        #종합 날씨 조회
        Wheather()
    elif s == menu['4']:
        #면세점 조회
        searchDutyFacilities()
    elif s == menu['5']:
        #비면세점 조회
        SearchNoDutyFacilities()
    else:
        Map()

    #RenderText.configure(state='disabled')


def MainSearch():
    global combo
    global window
    combo = ttk.Combobox(window,height = 70,width =50,state='readonly')
    combo['values'] = ('시간별 국제선','시간별 국내선','공항별 국내선','종합 날씨 조회','면세점 시설 검색','비면세점 시설 검색','공항 지도 사이트 연결')

    combo.place(x=65,y=100)
    action = ttk.Button(window,text ='검색',command=SearchButtonAction)
    action.place(x=442,y=99)




def StartTimeinput():
    global InputLabel
    TempFont = font.Font(window, size=15, weight='bold', family = 'Consolas')
    TimeText=Label(window,text='첫시간입력(00:00~24:00)',font=TempFont)
    InputLabel = Entry(window, font = TempFont, width = 26,relief = 'raised',bd=2.4)
    TimeText.place(x=50,y=115)
    InputLabel.place(x=300, y=115)

def EndTimeinput():
    global InputLabel
    TempFont = font.Font(window, size=15, weight='bold', family = 'Consolas')
    TimeText=Label(window,text='끝시간입력(00:00~24:00)',font=TempFont)
    InputLabel = Entry(window, font = TempFont, width = 26,relief = 'raised',bd=2.4)
    TimeText.place(x=50,y=145)
    InputLabel.place(x=300, y=145)


def InterStimeToGet():
    global startTime
    global endTime
    global sentry
    global eentry
    global key
    global RenderText
    startTime = sentry.get()
    endTime = eentry.get()

    InitRenderText()
    url = 'http://openapi.airport.co.kr/service/rest/FlightStatusList/getFlightStatusList?ServiceKey=' + key + '&schStTime=' + startTime + '&schEdTime=' + endTime + '&schLineType=I'
    resp = None
    try:
        resp = urllib.request.urlopen(url)
    except urllib.error.URLError as e:
        print(e.reason)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    except urllib.error.HTTPError as e:
        print("error code=" + e.code)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    else:
        response_body = resp.read()

        root = etree.fromstring(response_body)

        RenderText.configure(state='normal')
        RenderText.insert(INSERT,' 입력하신 공항의 운항 정보입니다.============\n')



        for child in root.iter('item'):
            airfin = child.find('airFln').text            #항공편명
            if child.find('airlineEnglish') != None:
                airline_english = child.find('airlineEnglish').text          #항공사(영문)
            if child.find('airlineKorean') != None:
                airline_korean = child.find('airlineKorean').text   #항공사 (국문)
            airport = child.find('airport').text                 #기준 공항 코드
            arrival_airport = child.find('arrivedKor').text                    #도착 공항(국문)
            boarding_airport = child.find('boardingKor').text                 #출발공항(국문)
            city = child.find('city').text      #운항구간 코드
            inout = child.find('io').text    #출/도착 코드
            line = child.find('line').text   #국내 국제 코드
            std = child.find('std').text     #예정시간

            RenderText.configure(state='normal')
            if airline_korean != None and airline_english !=None:
                RenderText.insert(INSERT,'\n 항공편명 = ')
                RenderText.insert(INSERT,airfin)
                RenderText.insert(INSERT, '\n 항공사(영어) = ')
                RenderText.insert(INSERT, airline_english)
                RenderText.insert(INSERT, '\n 항공사(한글) = ')
                RenderText.insert(INSERT, airline_korean)
                RenderText.insert(INSERT, '\n 기준공항 코드 = ')
                RenderText.insert(INSERT, airport)
                RenderText.insert(INSERT, '\n 출발 공항 = ')
                RenderText.insert(INSERT, boarding_airport)
                RenderText.insert(INSERT, '\n 도착 공항 = ')
                RenderText.insert(INSERT, arrival_airport)
                RenderText.insert(INSERT, '\n 운항 구간 코드 = ')
                RenderText.insert(INSERT, city)
                RenderText.insert(INSERT, '\n 출/도착 = ')
                RenderText.insert(INSERT, inout)
                RenderText.insert(INSERT, '\n 국내 국제 코드 = ')
                RenderText.insert(INSERT, line)
                RenderText.insert(INSERT, '\n 예정 시간 = ')
                RenderText.insert(INSERT, std)
                RenderText.insert(INSERT, '\n\n\n')
            elif airline_korean==None:
                RenderText.insert(INSERT, '\n 항공편명 = ')
                RenderText.insert(INSERT, airfin)
                RenderText.insert(INSERT, '\n 항공사(영어) = ')
                RenderText.insert(INSERT, airline_english)
                RenderText.insert(INSERT, '\n 기준공항 코드 = ')
                RenderText.insert(INSERT, airport)
                RenderText.insert(INSERT, '\n 출발 공항 = ')
                RenderText.insert(INSERT, boarding_airport)
                RenderText.insert(INSERT, '\n 도착 공항 = ')
                RenderText.insert(INSERT, arrival_airport)
                RenderText.insert(INSERT, '\n 운항 구간 코드 = ')
                RenderText.insert(INSERT, city)
                RenderText.insert(INSERT, '\n 출/도착 = ')
                RenderText.insert(INSERT, inout)
                RenderText.insert(INSERT, '\n 국내 국제 코드 = ')
                RenderText.insert(INSERT, line)
                RenderText.insert(INSERT, '\n 예정 시간 = ')
                RenderText.insert(INSERT, std)
                RenderText.insert(INSERT, '\n\n\n')
            elif airline_english ==None:
                RenderText.insert(INSERT, '\n 항공편명 = ')
                RenderText.insert(INSERT, airfin)
                RenderText.insert(INSERT, '\n 항공사(한글) = ')
                RenderText.insert(INSERT, airline_korean)
                RenderText.insert(INSERT, '\n 기준공항 코드 = ')
                RenderText.insert(INSERT, airport)
                RenderText.insert(INSERT, '\n 출발 공항 = ')
                RenderText.insert(INSERT, boarding_airport)
                RenderText.insert(INSERT, '\n 도착 공항 = ')
                RenderText.insert(INSERT, arrival_airport)
                RenderText.insert(INSERT, '\n 운항 구간 코드 = ')
                RenderText.insert(INSERT, city)
                RenderText.insert(INSERT, '\n 출/도착 = ')
                RenderText.insert(INSERT, inout)
                RenderText.insert(INSERT, '\n 국내 국제 코드 = ')
                RenderText.insert(INSERT, line)
                RenderText.insert(INSERT, '\n 예정 시간 = ')
                RenderText.insert(INSERT, std)
                RenderText.insert(INSERT, '\n\n\n')


            RenderText.configure(state='disabled')


def DomStimeToGet():
    global startTime
    global endTime
    global sentry
    global eentry
    global key
    global RenderText
    startTime = sentry.get()
    endTime = eentry.get()

    InitRenderText()
    url = 'http://openapi.airport.co.kr/service/rest/FlightStatusList/getFlightStatusList?ServiceKey=' + key + '&schStTime=' + startTime + '&schEdTime=' + endTime + '&schLineType=D'
    resp = None
    try:
        resp = urllib.request.urlopen(url)
    except urllib.error.URLError as e:
        print(e.reason)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    except urllib.error.HTTPError as e:
        print("error code=" + e.code)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    else:
        response_body = resp.read()

        root = etree.fromstring(response_body)


        RenderText.insert(INSERT, ' 입력하신 공항의 운항 정보입니다.============\n')


        for child in root.iter('item'):
            airfin = child.find('airFln').text  # 항공편명
            airline_english = child.find('airlineEnglish').text  # 항공사(영문)
            airline_korean = child.find('airlineKorean').text  # 항공사 (국문)
            airport = child.find('airport').text  # 기준 공항 코드
            arrival_airport = child.find('arrivedKor').text  # 도착 공항(국문)
            boarding_airport = child.find('boardingKor').text  # 출발공항(국문)
            city = child.find('city').text  # 운항구간 코드
            # estimate_time = child.find('etd') # 변경시간
            # gatenumber = child.find('gate').text #게이트 번호
            inout = child.find('io').text  # 출/도착 코드
            line = child.find('line').text  # 국내 국제 코드
            # airstatus = child.find('rmkKor').text #항공편 상태
            std = child.find('std').text  # 예정시간

            # print('항공편명 = '+airfin+'\n항공사(영어) = '+airline_english+'\n항공사(한글) = '+airline_korean+'\n기준공항 코드 = '+airport+'\n도착 공항 = '+arrival_airport+'\n출발 공항 = '+boarding_airport+
            #     '\n운항구간 코드= '+city+'\n출/도착코드 = '+inout+'\n국내 국제 코드 = '+line+'\n예정 시간 = '+std)
            RenderText.configure(state='normal')
            RenderText.insert(INSERT, '\n 항공편명 = ')
            RenderText.insert(INSERT, airfin)
            RenderText.insert(INSERT, '\n 항공사(영어) = ')
            RenderText.insert(INSERT, airline_english)
            RenderText.insert(INSERT, '\n 항공사(한글) = ')
            RenderText.insert(INSERT, airline_korean)
            RenderText.insert(INSERT, '\n 기준공항 코드 = ')
            RenderText.insert(INSERT, airport)
            RenderText.insert(INSERT, '\n 출발 공항 = ')
            RenderText.insert(INSERT, boarding_airport)
            RenderText.insert(INSERT, '\n 도착 공항 = ')
            RenderText.insert(INSERT, arrival_airport)
            RenderText.insert(INSERT, '\n 운항 구간 코드 = ')
            RenderText.insert(INSERT, city)
            RenderText.insert(INSERT, '\n 출/도착 = ')
            RenderText.insert(INSERT, inout)
            RenderText.insert(INSERT, '\n 국내 국제 코드 = ')
            RenderText.insert(INSERT, line)
            RenderText.insert(INSERT, '\n 예정 시간 = ')
            RenderText.insert(INSERT, std)
            RenderText.insert(INSERT, '\n\n\n')

            RenderText.configure(state='disabled')



def Inter_airline():
    global window
    global key
    global sentry
    global eentry

    tempFont = font.Font(window,size=15,weight ='bold',family='Consolas')
    stime = Label(window,text='예정시간을 입력하세요(00:00~24:00):')
    etime = Label(window,text ='변경시간을 입력하세요(00:00~24:00):')
    stime.pack()
    etime.pack()
    stime.place(x=60,y=145)
    etime.place(x=60,y=185)
    sentry = Entry(window)
    eentry = Entry(window)
    sentry.pack()
    eentry.pack()
    sentry.place(x=280,y=145)
    eentry.place(x=280,y=185)
    sbutton = Button(window,text='입력',command=InterStimeToGet)
    sbutton.pack()
    sbutton.place(x=450,y=185)





def dom_airline():
    global window
    global key
    global sentry
    global eentry

    tempFont = font.Font(window, size=15, weight='bold', family='Consolas')
    stime = Label(window, text='예정시간을 입력하세요(00:00~24:00):')
    etime = Label(window, text='변경시간을 입력하세요(00:00~24:00):')
    stime.pack()
    etime.pack()
    stime.place(x=60, y=145)
    etime.place(x=60, y=185)
    sentry = Entry(window)
    eentry = Entry(window)
    sentry.pack()
    eentry.pack()
    sentry.place(x=280, y=145)
    eentry.place(x=280, y=185)
    sbutton = Button(window, text='입력', command=DomStimeToGet)
    sbutton.pack()
    sbutton.place(x=450, y=185)


def airportGet():
    global sentry
    global eentry

    airport = sentry.get()
    time = eentry.get()
    InitRenderText()
    url = 'http://openapi.airport.co.kr/service/rest/FlightStatusList/getFlightStatusList?ServiceKey=' + key + \
          "&schStTime=" + time + '&schEdTime=2400&schLineType=D&schAirCode=' + airport

    RenderText.configure(state='normal')

    RenderText.insert(INSERT, "=============공항코드 정보=================\n")
    RenderText.insert(INSERT, "김포 = GMP  김해 = PUS  대구 = TAE  제주 = CJU  \n광주 = KWJ  청주 = CJJ  포항 = KPO  ")
    RenderText.insert(INSERT, "울산 = USN  \n진주 = HIN  원주 = WJU  양양 = YNY  여수 = RSU  \n목포 = MPK  군산 = KUV  무안 = MWX")
    RenderText.insert(INSERT, "\n=========================================\n")

    data = urllib.request.urlopen(url).read()

    root = etree.fromstring(data)
    for child in root.iter("item"):
        airline = child.find('airlineKorean').text
        start = child.find('boardingKor').text
        end = child.find('arrivedKor').text
        startTime = child.find('std').text


        RenderText.insert(INSERT,'\n 항공사 = ')
        RenderText.insert(INSERT, airline)
        RenderText.insert(INSERT,'\n 출발 공항 = ')
        RenderText.insert(INSERT, start)
        RenderText.insert(INSERT,'\n 도착 공항 = ')
        RenderText.insert(INSERT,end)
        RenderText.insert(INSERT,'\n 출발 시간 = ')
        RenderText.insert(INSERT,startTime)
        RenderText.insert(INSERT, '\n\n\n')

    RenderText.configure(state='disabled')


def airportDomainSearch():
    global sentry
    global eentry
    global RenderText
    InitRenderText()
    RenderText.configure(state='normal')
    RenderText.insert(INSERT,"=============공항코드 정보=================\n")
    RenderText.insert(INSERT,"김포 = GMP  김해 = PUS  대구 = TAE  제주 = CJU  \n광주 = KWJ  청주 = CJJ  포항 = KPO  ")
    RenderText.insert(INSERT,"울산 = USN  \n진주 = HIN  원주 = WJU  양양 = YNY  여수 = RSU  \n목포 = MPK  군산 = KUV  무안 = MWX")
    RenderText.insert(INSERT,"\n=========================================\n")

    tempFont = font.Font(window, size=15, weight='bold', family='Consolas')
    airport = Label(window,text="공항 코드를 입력하세요 : ")
    time = Label(window,text="시간대를 입력하세요 : ")
    airport.pack()
    time.pack()
    airport.place(x=60, y=145)
    time.place(x=60, y=185)
    sentry = Entry(window)
    eentry = Entry(window)
    sentry.pack()
    eentry.pack()
    sentry.place(x=280, y=145)
    eentry.place(x=280, y=185)
    RenderText.configure(state='disabled')
    sbutton = Button(window, text='입력', command=airportGet)
    sbutton.pack()
    sbutton.place(x=450, y=185)



def Wheather():
    global wheathercombo
    global window

    url = "http://newsky2.kma.go.kr/service/VilageFrcstDspthDocInfoService/WidGeneralWeatherCondition?ServiceKey=" + key + "&stnId=108"

    resp = None
    try:
        resp = urllib.request.urlopen(url)
    except urllib.error.URLError as e:
        print(e.reason)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    except urllib.error.HTTPError as e:
        print("error code=" + e.code)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    else:
        response_body = resp.read()

        root = etree.fromstring(response_body)

        RenderText.configure(state='normal')
        RenderText.delete(0.0, END)
        RenderText.insert(INSERT, ' 일주일간의 날씨 정보입니다.==================================\n')

        for child in root.iter('item'):
            btime = child.find('tmFc').text  # 발표시간
            today = child.find('wfSv1').text  # 오늘 날씨

            RenderText.insert(INSERT, '\n 발표시간 = ')
            RenderText.insert(INSERT, btime)
            RenderText.insert(INSERT, '\n 종합날씨 = ')
            RenderText.insert(INSERT, today)

        RenderText.configure(state='disabled')


def DutyGet():
    global sentry
    global eentry
    global dic
    global duty
    from urllib import parse

    facility = sentry.get()
    duty = facility
    if facility in dic.keys():
        encode = parse.quote(dic[facility])

        # parse.unquote()

        url = 'http://openapi.airport.kr/openapi/service/FacilitiesInformation/getFacilitesInfo?serviceKey=' + key + '&pageNo=1&startPage=1&numOfRows=176&pageSize=10&lang=K&lcduty=Y&facilitynm=' + encode

        resp = None
        try:
            resp = urllib.request.urlopen(url)
        except urllib.error.URLError as e:
            print(e.reason)
            print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
        except urllib.error.HTTPError as e:
            print("error code=" + e.code)
            print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
        else:
            response_body = resp.read()

            root = etree.fromstring(response_body)
        l1 = Label(window, text='\n 시설명 또는 매장명을 입력해주세요.')
        l1.pack()
        l1.place(x=60, y=145)
        sentry = Entry(window)
        sentry.pack()
        sentry.place(x=60, y=185)

        RenderText.configure(state='normal')
        RenderText.insert(INSERT,'\n\n\n            ***시설명으로 입력할 경우***\n\n\n')
        RenderText.insert(INSERT,'\n검색 키워드:    주류      담배     식품      화장품  \n\t\t국산      기념품   유아      완구  \n\t\t전자제품  패션     악세사리  향수  \n\t\t가방      신발     시계      럭셔리  \n\t\t한국      지갑     복합매장')
        RenderText.insert(INSERT,'\n\n\n            ***매장명으로 입력할 경우:***\n\n\n ')
        RenderText.insert(INSERT,'\n')
        RenderText.insert(INSERT,'                  매장 이름을 검색 해주세요  \n')
        sbutton = Button(window, text='입력', command=SearchSubfacilities)
        sbutton.pack()
        sbutton.place(x=450, y=185)
        RenderText.configure(state='disabled')




def searchDutyFacilities():
    global sentry
    global eentry
    global dic


    RenderText.configure(state='normal')

    RenderText.insert(INSERT,"============면세점 시설 검색================")

    RenderText.insert(INSERT,"\n\n")


    RenderText.insert(INSERT,'0: 신라면세점       1: 롯데면세점     2: SM면세점        3: 신세계면세점       \n4: 엔타스면세점     5: 시티면세점     6: 삼익면세점\n')

    l1 = Label(window,text='원하시는 면세점을 번호로 선택:')
    l1.pack()
    l1.place(x=60,y=145)
    sentry = Entry(window)
    sentry.pack()
    sentry.place(x=60 ,y=185)
    sbutton = Button(window, text='입력', command=DutyGet)
    sbutton.pack()
    sbutton.place(x=450, y=185)


    #facility = input('원하시는 면세점을 입력해주세요:')

    RenderText.configure(state='disabled')

def SearchSubfacilities():
    global RenderText
    global dic
    global duty

    RenderTextScrollbar = Scrollbar(window)
    RenderTextScrollbar.pack()
    RenderTextScrollbar.place(x=365, y=280)

    RenderText2 = Text(window, width=45, height=30, bd=3, relief='ridge', yscrollcommand=RenderTextScrollbar.set)
    RenderText2.pack()
    RenderText2.place(x=640, y=280)
    RenderTextScrollbar.config(command=RenderText.yview)
    from urllib import parse

    facility = duty

    if facility in dic.keys():
        encode = parse.quote(dic[facility])

        # parse.unquote()

        url = 'http://openapi.airport.kr/openapi/service/FacilitiesInformation/getFacilitesInfo?serviceKey=' + key + '&pageNo=1&startPage=1&numOfRows=176&pageSize=10&lang=K&lcduty=Y&facilitynm=' + encode

        resp = None
        try:
            resp = urllib.request.urlopen(url)
        except urllib.error.URLError as e:
            print(e.reason)
            print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
        except urllib.error.HTTPError as e:
            print("error code=" + e.code)
            print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
        else:
            response_body = resp.read()
            root = etree.fromstring(response_body)

        count = 0
        for child in root.iter('item'):
            sn = child.find('sn').text  # 시설별 시퀀스 번호
            facilityItem = child.find('facilityitem').text  # 취급품목
            facilityName = child.find('facilitynm').text  # 시설명 or 매장명
            location = child.find('lcnm').text  # 시설 위치 설명
            if child.find('goods') != None:
                goods = child.find('goods').text  # 취급품목 브랜드
            else:
                goods = None
            servicetime = child.find('servicetime').text  # 서비스 시간
            if child.find('terminalid') != None:
                terminalid = child.find('terminalid').text  # 터미널 구분
            else:
                terminalid = None
            floor = child.find('floorinfo').text  # 층 구분
            if child.find('tel') != None:
                tel = child.find('tel').text  # 전화번호
            else:
                tel = None

            if sentry.get() in facilityName:
                count += 1
                RenderText2.configure(state='normal')
                # encode2 = parse.quote(facilityName)
                # url = 'http://openapi.airport.kr/openapi/service/FacilitiesInformation/getFacilitesInfo?serviceKey=' + key + '&pageNo=1&startPage=1&numOfRows=176&pageSize=10&lang=K&lcduty=Y&facilitynm=' + encode+' '+encode2
                if tel == None and terminalid == None and goods != None:
                    #print(
                    #    '\n시설별 시퀀스 번호=' + sn + '\n취급 품목 =' + facilityItem + '\n시설명/매장명 =' + facilityName + '\n시설 위치 =' + location + '\n취급 품목 브랜드 =' + goods + '\n서비스 시간 =' + servicetime + \
                    #    '\n층 =' + floor)
                    RenderText2.insert(INSERT,'\n시설별 시퀀스 번소 = ')
                    RenderText2.insert(INSERT,sn)
                    RenderText2.insert(INSERT,'\n취급 품목 = ')
                    RenderText2.insert(INSERT, facilityItem)
                    RenderText2.insert(INSERT, '\n시설명/매장명 = ')
                    RenderText2.insert(INSERT, facilityName)
                    RenderText2.insert(INSERT, '\n시설 위치 = ')
                    RenderText2.insert(INSERT, location)
                    RenderText2.insert(INSERT, '\n취급 품목 브랜드 =')
                    RenderText2.insert(INSERT, goods)
                    RenderText2.insert(INSERT, '\n서비스 시간 = ')
                    RenderText2.insert(INSERT, servicetime)
                    RenderText2.insert(INSERT, '\n층 = ')
                    RenderText2.insert(INSERT, floor)
                    RenderText2.insert(INSERT, "\n\n\n")

                elif tel == None and terminalid != None:
                    #print(
                    #    '\n시설별 시퀀스 번호=' + sn + '\n취급 품목 =' + facilityItem + '\n시설명/매장명 =' + facilityName + '\n시설 위치 =' + location + '\n서비스 시간 =' + servicetime + \
                    #    '\n터미널 =' + terminalid + '\n층 =' + floor)
                    RenderText2.insert(INSERT, '\n시설별 시퀀스 번소 = ')
                    RenderText2.insert(INSERT, sn)
                    RenderText2.insert(INSERT, '\n취급 품목 = ')
                    RenderText2.insert(INSERT, facilityItem)
                    RenderText2.insert(INSERT, '\n시설명/매장명 = ')
                    RenderText2.insert(INSERT, facilityName)
                    RenderText2.insert(INSERT, '\n시설 위치 = ')
                    RenderText2.insert(INSERT, location)
                    RenderText2.insert(INSERT, '\n서비스 시간 = ')
                    RenderText2.insert(INSERT, servicetime)
                    RenderText2.insert(INSERT, '\n층 = ')
                    RenderText2.insert(INSERT, floor)
                    RenderText2.insert(INSERT,'\n터미널 = ')
                    RenderText2.insert(INSERT,terminalid)
                    RenderText2.insert(INSERT, "\n\n\n")
                elif goods == None:
                    #print(
                    #    '\n시설별 시퀀스 번호=' + sn + '\n취급 품목 =' + facilityItem + '\n시설명/매장명 =' + facilityName + '\n시설 위치 =' + location + '\n서비스 시간 =' + servicetime + \
                     #   '\n터미널 =' + terminalid + '\n층 =' + floor + '\n전화번호 =' + tel)
                    RenderText2.insert(INSERT, '\n시설별 시퀀스 번소 = ')
                    RenderText2.insert(INSERT, sn)
                    RenderText2.insert(INSERT, '\n취급 품목 = ')
                    RenderText2.insert(INSERT, facilityItem)
                    RenderText2.insert(INSERT, '\n시설명/매장명 = ')
                    RenderText2.insert(INSERT, facilityName)
                    RenderText2.insert(INSERT, '\n시설 위치 = ')
                    RenderText2.insert(INSERT, location)
                    RenderText2.insert(INSERT, '\n서비스 시간 = ')
                    RenderText2.insert(INSERT, servicetime)
                    RenderText2.insert(INSERT, '\n층 = ')
                    RenderText2.insert(INSERT, floor)
                    RenderText2.insert(INSERT, '\n터미널 = ')
                    RenderText2.insert(INSERT, terminalid)
                    RenderText2.insert(INSERT,'\n전화번호 = ')
                    RenderText2.insert(INSERT,tel)
                    RenderText2.insert(INSERT, "\n\n\n")

                elif terminalid == None:
                    #print(
                    #    '\n시설별 시퀀스 번호=' + sn + '\n취급 품목 =' + facilityItem + '\n시설명/매장명 =' + facilityName + '\n시설 위치 =' + location + '\n취급 품목 브랜드 =' + goods + '\n서비스 시간 =' + servicetime + \
                    #    '\n층 =' + floor + '\n전화번호 =' + tel)
                    RenderText2.insert(INSERT, '\n시설별 시퀀스 번소 = ')
                    RenderText2.insert(INSERT, sn)
                    RenderText2.insert(INSERT, '\n취급 품목 = ')
                    RenderText2.insert(INSERT, facilityItem)
                    RenderText2.insert(INSERT, '\n시설명/매장명 = ')
                    RenderText2.insert(INSERT, facilityName)
                    RenderText2.insert(INSERT, '\n시설 위치 = ')
                    RenderText2.insert(INSERT, location)
                    RenderText2.insert(INSERT,'\n취급 품목 브랜드 = ')
                    RenderText2.insert(INSERT,goods)
                    RenderText2.insert(INSERT, '\n서비스 시간 = ')
                    RenderText2.insert(INSERT, servicetime)
                    RenderText2.insert(INSERT, '\n층 = ')
                    RenderText2.insert(INSERT, floor)
                    RenderText2.insert(INSERT, '\n전화번호 = ')
                    RenderText2.insert(INSERT, tel)
                    RenderText2.insert(INSERT, "\n\n\n")
                elif tel != None and goods != None:
                    #print(
                    #    '\n시설별 시퀀스 번호=' + sn + '\n취급 품목 =' + facilityItem + '\n시설명/매장명 =' + facilityName + '\n시설 위치 =' + location + '\n취급 품목 브랜드 =' + goods + '\n서비스 시간 =' + servicetime + \
                    #    '\n터미널 =' + terminalid + '\n층 =' + floor + '\n전화번호 =' + tel)
                    RenderText2.insert(INSERT, '\n시설별 시퀀스 번소 = ')
                    RenderText2.insert(INSERT, sn)
                    RenderText2.insert(INSERT, '\n취급 품목 = ')
                    RenderText2.insert(INSERT, facilityItem)
                    RenderText2.insert(INSERT, '\n시설명/매장명 = ')
                    RenderText2.insert(INSERT, facilityName)
                    RenderText2.insert(INSERT, '\n시설 위치 = ')
                    RenderText2.insert(INSERT, location)
                    RenderText2.insert(INSERT, '\n취급 품목 브랜드 = ')
                    RenderText2.insert(INSERT, goods)
                    RenderText2.insert(INSERT, '\n서비스 시간 = ')
                    RenderText2.insert(INSERT, servicetime)
                    RenderText2.insert(INSERT, '\n층 = ')
                    RenderText2.insert(INSERT, floor)
                    RenderText2.insert(INSERT, '\n전화번호 = ')
                    RenderText2.insert(INSERT, tel)
                    RenderText2.insert(INSERT,'\n터미널 = ')
                    RenderText2.insert(INSERT,terminalid)
                    RenderText2.insert(INSERT,"\n\n\n")

        if count == 0:
            RenderText2.insert(INSERT,'\n해당 품목이 면세점에 없습니다.')

def InitRenderText():
    global RenderText
    global window



    RenderTextScrollbar = Scrollbar(window)
    RenderTextScrollbar.pack()
    RenderTextScrollbar.place(x=365, y=280)

    TempFont = font.Font(window, size=10, family='Consolas')
    RenderText = Text(window, width=80, height=30, bd=3, relief='ridge', yscrollcommand=RenderTextScrollbar.set)
    RenderText.pack()
    RenderText.place(x=60, y=280)
    RenderTextScrollbar.config(command=RenderText.yview)

    RenderText.configure(state='disabled')


def SearchNoDutyFacilities():
    global NoDutycombo
    global window
    NoDutycombo = ttk.Combobox(window, height=70, width=50, state='readonly')
    NoDutycombo['values'] = ('공항시설', '공항명소', '일반쇼핑', '음식점')

    NoDutycombo.place(x=65, y=150)
    action = ttk.Button(window, text='검색', command=NoDutyAction)
    action.place(x=442, y=150)

def NoDutyAction():
    from urllib import parse
    global NoDutycombo
    global NoDutyActioncombo
    global window
    global NoDutyEntry

    #key = 'QydOrzDVYNDcxRwTCTjElQ8FWVC7fQgJ8JVlglIlMmFtva3gU65%2BRmV%2FlyxorjQzmRAiXGxM%2F2E1PXAC56NWdg%3D%3D'
    url = 'http://openapi.airport.kr/openapi/service/FacilitiesInformation/getFacilitesInfo?serviceKey=' + key + '&pageNo=1&startPage=1&numOfRows=320&pageSize=320&lang=K&lcduty=N'

    resp = None
    try:
        resp = urllib.request.urlopen(url)
    except urllib.error.URLError as e:
        print(e.reason)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    except urllib.error.HTTPError as e:
        print("error code=" + e.code)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    else:
        response_body = resp.read()

        root = etree.fromstring(response_body)
    store = NoDutycombo.get()

    RenderText.configure(state='normal')
    RenderText.delete(0.0, END)

    for child in root.iter('item'):
        if store in child.find('lcategorynm').text:
            RenderText.insert(INSERT,child.find('facilitynm').text)
            RenderText.insert(INSERT,'\n')

    NoDutyLabel = Label(window, text='상세하게 알고싶은 가게명을 입력하세요')
    NoDutyLabel.place(x=60, y=225)
    NoDutyEntry = Entry(window)
    NoDutyEntry.place(x=280, y=225)
    NoDutysecondbutton = Button(window, text='입력', command=NoDutyName)
    NoDutysecondbutton.place(x=450, y=225)
def NoDutyName():

    global NoDutyEntry

    url = 'http://openapi.airport.kr/openapi/service/FacilitiesInformation/getFacilitesInfo?serviceKey=' + key + '&pageNo=1&startPage=1&numOfRows=320&pageSize=320&lang=K&lcduty=N'

    resp = None
    try:
        resp = urllib.request.urlopen(url)
    except urllib.error.URLError as e:
        print(e.reason)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    except urllib.error.HTTPError as e:
        print("error code=" + e.code)
        print(urllib.request.parseString(e.read().decode('utf-8')).toprettyxml())
    else:
        response_body = resp.read()

        root = etree.fromstring(response_body)

    store = NoDutyEntry.get()


    for child in root.iter('item'):
        RenderText.delete(0.0,END)
        RenderText.configure(state='normal')
        if store in child.find('facilitynm').text:
            name = child.find('facilitynm').text
            floor = child.find('floorinfo').text
            location = child.find('lcnm').text
            servicetime = child.find('servicetime').text
            serialnum = child.find('sn').text
            if child.find('tel') != None:
                tel = child.find('tel').text
            else:
                tel = None
            terminalId = child.find('terminalid').text

            #RenderText.configure(state='normal')
            #RenderText.delete(0.0, END)

            if tel != None:
                RenderText.insert(INSERT, '\n가게 이름 : ')
                RenderText.insert(INSERT, name)
                RenderText.insert(INSERT, '\n층 : ')
                RenderText.insert(INSERT, floor)
                RenderText.insert(INSERT, '\n매장위치 : ')
                RenderText.insert(INSERT, location)
                RenderText.insert(INSERT, '\n영업시간 : ')
                RenderText.insert(INSERT, servicetime)
                RenderText.insert(INSERT, '\n매장번호 : ')
                RenderText.insert(INSERT, serialnum)
                RenderText.insert(INSERT, '\n전화번호 : ')
                RenderText.insert(INSERT, tel)
                RenderText.insert(INSERT, '\n터미널 : ')
                RenderText.insert(INSERT, terminalId)
                RenderText.insert(INSERT, '\n\n\n')

            elif tel == None:
                RenderText.insert(INSERT, '\n가게 이름 : ')
                RenderText.insert(INSERT, name)
                RenderText.insert(INSERT, '\n층 : ')
                RenderText.insert(INSERT, floor)
                RenderText.insert(INSERT, '\n매장위치 : ')
                RenderText.insert(INSERT, location)
                RenderText.insert(INSERT, '\n영업시간 : ')
                RenderText.insert(INSERT, servicetime)
                RenderText.insert(INSERT, '\n매장번호 : ')
                RenderText.insert(INSERT, serialnum)
                RenderText.insert(INSERT, '\n터미널 : ')
                RenderText.insert(INSERT, terminalId)
                RenderText.insert(INSERT,'\n\n\n')
        RenderText.configure(state='disabled')

def Map():
    global sentry
    RenderText.configure(state='normal')
    RenderText.insert(INSERT,"=========공항 지도를 웹으로 연결하시겠습니까?===========\n\n\n")
    RenderText.insert(INSERT,"\n=========예(y)/아니오(n)==========================\n")
    yn = Label(window,text='예/아니오')
    yn.pack()
    yn.place(x=60,y=145)
    sentry = Entry(window)
    sentry.pack()
    sentry.place(x=60,y=180)
    button = Button(window, text='입력', command=mapAction)
    button.pack()
    button.place(x=450, y=180)



def mapAction():
    global sentry


    if sentry.get() == '예':
        RenderText.insert(INSERT,'\n공항 지도 보기를 선택하였습니다.')
        new_url = 'https://www.airport.kr/ap/ko/map/mapInfo.do'
        return webbrowser.open_new(new_url)
    else:
        RenderText.insert(INSERT,'\n공항 지도 연결을 건너뛰었습니다.')

    RenderText.configure(state='disabled')

window.geometry("1000x750+450+100")

TopText()
InitRenderText()
MainSearch()

window.mainloop()
