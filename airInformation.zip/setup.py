from distutils.core import setup,Extension

setup(name='airInformation',
version = '1.0',
classifiers = ['airInformation'],
packages=['airInformation'],
      )
